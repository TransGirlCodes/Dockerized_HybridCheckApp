.onAttach <- function(...){
  packageStartupMessage("\nTACCGATTTGTACCTAAGTATGCATTACGTTACGTTAGTAGCTGGACCTAGTAAATCGGA  
 _   _       _          _     _  _____ _               _    
| | | |     | |        (_)   | |/  __ | |             | |   
| |_| |_   _| |__  _ __ _  __| || /  \\| |__   ___  ___| | __
|  _  | | | | '_ \\| '__| |/ _` || |   | '_ \\ / _ \\/ __| |/ /
| | | | |_| | |_) | |  | | (_| || \\__/| | | |  __| (__|   < 
\\_| |_/\\__, |_.__/|_|  |_|\\__,_| \\____|_| |_|\\___|\\___|_|\\_\\
        __/ |                                                     
       |___/                                                      
ATGAAACATGGATTCATACGAA - Version 0.1 - CGACGCTGGATCATTTAGCCT\n\n
Hybridisation, Recombination and Introgression Detection
                   and Dating Package.\n
-----------------=========****=========------------------
Cite: TBD
Licence: GPL (Like R and most packages).
http://ward9250.github.io/Hybrid-Check/
-----------------=========****=========------------------\n")
}